def hola_mundo():
    print("¡Hola, mundo desde el módulo 2!")


def hola_mundo2():
    print("¡Hola, mundo2 desde el módulo 2!")
